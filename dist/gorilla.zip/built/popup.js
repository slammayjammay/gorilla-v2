/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/dom/index.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/dom/AceConfig.js":
/*!******************************!*\
  !*** ./src/dom/AceConfig.js ***!
  \******************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

eval("const { $, $$ } = __webpack_require__(/*! ../helpers/query-selector */ \"./src/helpers/query-selector.js\");\nconst formatCode = __webpack_require__(/*! ../helpers/format-code */ \"./src/helpers/format-code.js\");\nconst ConfigPanel = __webpack_require__(/*! ./ConfigPanel */ \"./src/dom/ConfigPanel.js\");\nconst configureEditor = __webpack_require__(/*! ./configure-editor */ \"./src/dom/configure-editor.js\");\n\nmodule.exports = class AceConfig extends ConfigPanel {\n\tstatic get optionPath() {\n\t\treturn 'aceOptions';\n\t}\n\n\tstatic get editorCode() {\n\t\treturn formatCode.dedent(`\n\t\t\tfunction configureEditor(editor) {\n\t\t\t\teditor.setTheme('ace/theme/monokai');\n\t\t\t\teditor.session.setMode('ace/mode/javascript');\n\t\t\t\teditor.setKeyboardHandler('ace/keyboard/sublime');\n\t\t\t}\n\t\t`).trim();\n\t}\n\n\tconstructor() {\n\t\tsuper(...arguments);\n\t\t$('.apply', this.el).addEventListener('click', () => configureEditor(this.editor));\n\t}\n\n\tcreateEl() {\n\t\tconst dummy = document.createElement('div');\n\t\tdummy.innerHTML = `\n\t\t\t<details>\n\t\t\t\t<summary>Configure Editor</summary>\n\t\t\t\t<p>This extension loads the <a href=\"https://ace.c9.io/\">Ace editor</a> <a href=\"https://cdnjs.cloudflare.com/ajax/libs/ace/1.4.12/ace.js\">CDN</a> for text editing. You can configure the editor by adjusting the function below. This function will be called for all instances of Ace editors used in this extension.</p>\n\t\t\t\t<p>\n\t\t\t\t\t<button class=\"button restore-default\" title=\"Restore defaults\"><small>restore defaults</small></button>\n\t\t\t\t\t<button class=\"button apply\" title=\"Apply\"><small>apply</small></button>\n\t\t\t\t</p>\n\t\t\t\t<small class=\"save\" data-saved=\"Saved.\" data-saving=\"Saving...\">Saved.</small>\n\t\t\t\t<div class=\"editor-container\"></div>\n\t\t\t</details>\n\t\t`;\n\t\treturn dummy.children[0];\n\t}\n};\n\n\n//# sourceURL=webpack:///./src/dom/AceConfig.js?");

/***/ }),

/***/ "./src/dom/ConfigPanel.js":
/*!********************************!*\
  !*** ./src/dom/ConfigPanel.js ***!
  \********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

eval("const { $, $$ } = __webpack_require__(/*! ../helpers/query-selector */ \"./src/helpers/query-selector.js\");\nconst storage = __webpack_require__(/*! ./storage */ \"./src/dom/storage.js\");\nconst createEditor = __webpack_require__(/*! ./create-editor */ \"./src/dom/create-editor.js\");\nconst configureEditor = __webpack_require__(/*! ./configure-editor */ \"./src/dom/configure-editor.js\");\n\nmodule.exports = class OptionPanel {\n\tstatic get optionPath() {\n\t\tthrow new Error('Missing optionPath.');\n\t}\n\n\tstatic getOption() {\n\t\tconst stored = storage.get(this.optionPath);\n\t\treturn stored ? decodeURIComponent(stored) : this.constructor.editorCode;\n\t}\n\n\tstatic get editorCode() {\n\t\treturn '';\n\t}\n\n\tconstructor() {\n\t\tthis.el = this.createEl();\n\t\tthis.editor = null;\n\t\tthis._id = null;\n\n\t\tthis.createEditor();\n\t\t$('.restore-default', this.el).addEventListener('click', () => this.restoreDefault());\n\t}\n\n\tcreateEl() {\n\t\tthrow new Error('Missing createEl.');\n\t}\n\n\tasync createEditor() {\n\t\tawait storage.loadOnce();\n\t\tif (!storage.has(this.constructor.optionPath)) {\n\t\t\tstorage.set(this.constructor.optionPath, encodeURIComponent(this.constructor.editorCode));\n\t\t}\n\t\tthis.editor = createEditor($('.editor-container', this.el));\n\t\tthis.editor.setValue(this.constructor.getOption(), -1);\n\t\tthis.editor.on('change', () => this.onChange());\n\t\tconfigureEditor();\n\t}\n\n\tonChange() {\n\t\tclearTimeout(this._id);\n\t\tthis._id = setTimeout(() => this._onChange(...arguments), 500);\n\t\tconst save = $('.save', this.el);\n\t\tsave && (save.textContent = save.getAttribute('data-saving'));\n\t}\n\n\t_onChange() {\n\t\tstorage.set(this.constructor.optionPath, encodeURIComponent(this.editor.getValue()));\n\t\tstorage.save();\n\t\tconst save = $('.save', this.el);\n\t\tsave && (save.textContent = save.getAttribute('data-saved'));\n\t}\n\n\trestoreDefault() {\n\t\tstorage.set(this.constructor.optionPath, encodeURIComponent(this.constructor.editorCode));\n\t\tstorage.save();\n\t\tthis.editor.setValue(this.constructor.getOption(), -1);\n\t}\n};\n\n\n//# sourceURL=webpack:///./src/dom/ConfigPanel.js?");

/***/ }),

/***/ "./src/dom/DelimitedMap.js":
/*!*********************************!*\
  !*** ./src/dom/DelimitedMap.js ***!
  \*********************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("// Map-like API, except uses JSON structure and '.' deliminated keys:\n// { root: { nested: true } } --> get('root.nested')\nmodule.exports = class DelimitedMap {\n\tconstructor(json = {}) {\n\t\tthis.json = json;\n\t}\n\n\tdeliminateKeys(keys) {\n\t\treturn Array.isArray(keys) ? keys : keys.split('.');\n\t}\n\n\tsplitLast(keys) {\n\t\tkeys = this.deliminateKeys(keys);\n\t\tconst rest = keys.slice(0, -1);\n\t\tconst last = keys[keys.length - 1];\n\t\treturn [rest, last];\n\t}\n\n\tget(keys) {\n\t\tif (!Array.isArray(keys) && typeof keys !== 'string') {\n\t\t\treturn this.json;\n\t\t}\n\n\t\tkeys = this.deliminateKeys(keys);\n\t\tlet cur = this.json;\n\t\tkeys.forEach(key => cur = cur[key]);\n\t\treturn cur;\n\t}\n\n\thas(keys) {\n\t\treturn !!this.get(keys);\n\t}\n\n\tset(keys, val) {\n\t\tconst [rest, last] = this.splitLast(keys);\n\t\tlet cur = this.json;\n\n\t\trest.forEach(key => {\n\t\t\t(cur[key] === undefined) && (cur[key] = {});\n\t\t\tcur = cur[key];\n\t\t});\n\n\t\tcur[last] = val;\n\t}\n\n\tdelete(keys) {\n\t\tif (typeof keys !== 'string') {\n\t\t\treturn false;\n\t\t}\n\n\t\tkeys = this.deliminateKeys(keys);\n\t\tconst [rest, last] = this.splitLast(keys);\n\t\tconst almost = this.get(rest);\n\n\t\tif (!almost || !last) {\n\t\t\treturn false;\n\t\t}\n\n\t\treturn delete almost[last];\n\t}\n\n\tclear(keys) {\n\t\treturn keys ? this.set(keys, {}) : (this.json = {});\n\t}\n\n\tforEach(keys, cb) {\n\t\tif (typeof keys !== 'string') {\n\t\t\tcb = keys;\n\t\t\tkeys = null;\n\t\t}\n\n\t\tconst obj = this.get(keys);\n\t\tif (typeof obj !== 'object') {\n\t\t\treturn;\n\t\t}\n\n\t\tconst entries = Object.entries(obj);\n\t\treturn entries.forEach(([key, val], idx) => cb(key, val, idx));\n\t}\n\n\ttoString(...options) {\n\t\treturn JSON.stringify(this.json, ...options);\n\t}\n};\n\n\n//# sourceURL=webpack:///./src/dom/DelimitedMap.js?");

/***/ }),

/***/ "./src/dom/ExtensionData.js":
/*!**********************************!*\
  !*** ./src/dom/ExtensionData.js ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

eval("const { $, $$ } = __webpack_require__(/*! ../helpers/query-selector */ \"./src/helpers/query-selector.js\");\nconst storage = __webpack_require__(/*! ./storage */ \"./src/dom/storage.js\");\nconst eventBus = __webpack_require__(/*! ./event-bus */ \"./src/dom/event-bus.js\");\n\nmodule.exports = class ExtensionData {\n\tconstructor() {\n\t\tthis.el = this.createEl();\n\n\t\tthis.updateBytes();\n\n\t\t$('.storage-copy', this.el).addEventListener('click', () => this.copyData());\n\t\t$('.storage-save', this.el).addEventListener('click', () => this.editData());\n\t\t$('.storage-download', this.el).addEventListener('click', () => this.downloadData());\n\t\t$('.bytes-refresh', this.el).addEventListener('click', () => this.updateBytes());\n\n\t\tstorage.loadOnce().then(() => this.updateStorage());\n\t\teventBus.on('storage-save', () => this.updateStorageText());\n\t}\n\n\tcreateEl() {\n\t\tconst dummy = document.createElement('div');\n\t\tdummy.innerHTML = `\n\t\t\t<details>\n\t\t\t\t<summary>Misc</summary>\n\t\t\t\t<details>\n\t\t\t\t\t<summary>View/Edit extension json</summary>\n\t\t\t\t\t<p><strong><span class=\"bytes\"></span></strong> bytes stored locally. <button class=\"button bytes-refresh\" title=\"refresh\">&orarr;</button></p>\n\t\t\t\t\t<p>\n\t\t\t\t\t\t<button class=\"button storage-copy\" title=\"Copy json\">Copy</button>\n\t\t\t\t\t\t<button class=\"button storage-save\" title=\"Save json\">Save</button>\n\t\t\t\t\t\t<button class=\"button storage-download\" title=\"Download json\">Download</button>\n\t\t\t\t\t</p>\n\t\t\t\t\t<p><small>(Note: scripts must be <a href=\"https://developer.mozilla.org/en-US/search?q=encodeuricomponent\">URI encoded</a>.)</small></p>\n\t\t\t\t\t<div class=\"storage-container\">\n\t\t\t\t\t\t<textarea></textarea>\n\t\t\t\t\t\t<pre class=\"storage\" contenteditable=\"true\"></pre>\n\t\t\t\t\t</div>\n\t\t\t\t</details>\n\t\t\t\t<div class=\"ace-config\"></div>\n\t\t\t\t<div class=\"window-config\"></div>\n\t\t\t\t<div class=\"startup-js\"></div>\n\t\t\t</details>\n\t\t`;\n\t\treturn dummy.children[0];\n\t}\n\n\tasync updateBytes() {\n\t\tconst bytes = await new Promise(r => chrome.storage.local.getBytesInUse(r));\n\t\t$('.bytes', this.el).textContent = bytes;\n\t}\n\n\tcopyData() {\n\t\tconst textarea = $('.storage-container textarea', this.el);\n\t\ttextarea.value = storage.toString(null, 2);\n\t\ttextarea.select();\n\t\tdocument.execCommand('copy');\n\t}\n\n\teditData() {\n\t\tlet json;\n\t\ttry {\n\t\t\tjson = JSON.parse($('.storage', this.el).textContent);\n\t\t} catch(e) {\n\t\t\treturn alert('JSON is not valid.');\n\t\t}\n\n\t\tstorage.json = json;\n\t\tstorage.save();\n\t\tthis.updateStorage();\n\t}\n\n\tdownloadData() {\n\t\tconst a = document.createElement('a');\n\t\tconst data = storage.toString(null, 2);\n\t\tconst href = `data:text/json;charset=utf-8,${encodeURIComponent(data)}`;\n\t\ta.setAttribute('href', href);\n\t\ta.setAttribute('download', 'gorilla.json');\n\t\ta.click();\n\t}\n\n\tupdateStorage() {\n\t\tthis.updateStorageText();\n\t}\n\n\tupdateStorageText() {\n\t\t$('.storage', this.el).textContent = storage.toString(null, 2);\n\t}\n}\n\n\n//# sourceURL=webpack:///./src/dom/ExtensionData.js?");

/***/ }),

/***/ "./src/dom/Gorilla.js":
/*!****************************!*\
  !*** ./src/dom/Gorilla.js ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

eval("const css = __webpack_require__(/*! ./css */ \"./src/dom/css.js\");\nconst { $, $$ } = __webpack_require__(/*! ../helpers/query-selector */ \"./src/helpers/query-selector.js\");\nconst eventBus = __webpack_require__(/*! ./event-bus */ \"./src/dom/event-bus.js\");\nconst storage = __webpack_require__(/*! ./storage */ \"./src/dom/storage.js\");\nconst TabSelection = __webpack_require__(/*! ./TabSelection */ \"./src/dom/TabSelection.js\");\nconst Scripts = __webpack_require__(/*! ./Scripts */ \"./src/dom/Scripts.js\");\n\nmodule.exports = class Gorilla {\n\tconstructor() {\n\t\tthis.container = document.getElementById('gorilla');\n\t\tthis.scripts = new Scripts();\n\n\t\tthis.el = this.createEl();\n\t\tthis.container.append(this.el);\n\n\t\teventBus.on('scriptCreated', e => this.onScriptCreated(e));\n\t\teventBus.on('scriptDeleted', e => this.onScriptDeleted(e));\n\t\teventBus.on('scriptRun', e => this.onScriptRun(e));\n\t\teventBus.on('close', e => window.close());\n\n\t\tthis._isPopup = this._tabSelection = null;\n\t\tthis.isPopup().then(bool => {\n\t\t\tthis._isPopup = bool;\n\t\t\tdocument.documentElement.classList.add(bool ? 'window' : 'popup');\n\t\t\tthis._isPopup ? this.addPopupHTML() : this.addInlineHTML();\n\t\t\teventBus.emit('isPopup');\n\t\t});\n\n\t\tthis.inject();\n\t}\n\n\tcreateEl() {\n\t\tconst dummy = document.createElement('div');\n\t\tdummy.innerHTML = `\n\t\t\t<div>\n\t\t\t\t<h1>Gorilla</h1>\n\t\t\t</div>\n\t\t`;\n\t\tdummy.children[0].append(this.scripts.el);\n\t\treturn dummy.children[0];\n\t}\n\n\tasync isPopup() {\n\t\treturn new Promise(resolve => {\n\t\t\tchrome.tabs.query({ active: true, currentWindow: true }, tabs => {\n\t\t\t\tresolve(tabs[0].url === chrome.runtime.getURL('/popup.html'));\n\t\t\t});\n\t\t});\n\t}\n\n\taddInlineHTML() {\n\t\tconst dummy = document.createElement('div');\n\t\tdummy.innerHTML = `<button class=\"open-popup\" title=\"Open in separate window\">&#8689;</button>`;\n\t\tconst button = dummy.children[0];\n\t\tthis.el.prepend(button);\n\n\t\tbutton.addEventListener('click', () => {\n\t\t\tchrome.runtime.sendMessage({ name: 'open-popup' });\n\t\t\twindow.close();\n\t\t});\n\t}\n\n\taddPopupHTML() {\n\t\tthis._tabSelection = new TabSelection();\n\t\t$('.tab-selection', this.scripts.el).append(this._tabSelection.el);\n\t}\n\n\tinject() {\n\t\tthis.injectCSS();\n\t\tthis.isActive = true;\n\t}\n\n\tinjectCSS() {\n\t\tconst style = document.createElement('style');\n\t\tstyle.id = '_gorilla-style';\n\t\tstyle.textContent = css;\n\t\tthis.container.prepend(style);\n\t}\n\n\tonScriptCreated(e) {\n\t\tconst data = e.detail;\n\t\tstorage.set(`scripts.${data.get('name')}`, {\n\t\t\tscript: encodeURIComponent(data.get('script')),\n\t\t\trunAt: data.get('run-at')\n\t\t});\n\t\tstorage.save();\n\t}\n\n\tonScriptDeleted(e) {\n\t\tconst name = e.detail;\n\t\tstorage.delete(`scripts.${name}`);\n\t\tstorage.save();\n\t}\n\n\tonScriptRun(e) {\n\t\tchrome.runtime.sendMessage({\n\t\t\tname: 'run-script',\n\t\t\tscriptName: e.detail,\n\t\t\ttabQuery: this._tabSelection && this._tabSelection.getSelectedTab()\n\t\t}, response => {\n\t\t\teventBus.emit('scriptStatus', { name: e.detail, error: response.error });\n\t\t});\n\t}\n};\n\n\n//# sourceURL=webpack:///./src/dom/Gorilla.js?");

/***/ }),

/***/ "./src/dom/Scripts.js":
/*!****************************!*\
  !*** ./src/dom/Scripts.js ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

eval("const { $, $$ } = __webpack_require__(/*! ../helpers/query-selector */ \"./src/helpers/query-selector.js\");\nconst eventBus = __webpack_require__(/*! ./event-bus */ \"./src/dom/event-bus.js\");\nconst storage = __webpack_require__(/*! ./storage */ \"./src/dom/storage.js\");\nconst generateScript = __webpack_require__(/*! ../helpers/generate-script */ \"./src/helpers/generate-script.js\");\nconst createEditor = __webpack_require__(/*! ./create-editor */ \"./src/dom/create-editor.js\");\nconst configureEditor = __webpack_require__(/*! ./configure-editor */ \"./src/dom/configure-editor.js\");\nconst ExtensionData = __webpack_require__(/*! ./ExtensionData */ \"./src/dom/ExtensionData.js\");\nconst AceConfig = __webpack_require__(/*! ./AceConfig */ \"./src/dom/AceConfig.js\");\nconst WindowConfig = __webpack_require__(/*! ./WindowConfig */ \"./src/dom/WindowConfig.js\");\nconst StartupJS = __webpack_require__(/*! ./StartupJS */ \"./src/dom/StartupJS.js\");\n\nconst boilerplate = `function script($, $$) {\\n\\t/* your code here */\\n}`;\n\nmodule.exports = class Scripts {\n\tconstructor() {\n\t\tthis.onScriptClick = this.onScriptClick.bind(this);\n\n\t\tthis.extensionData = new ExtensionData();\n\t\tthis.aceConfig = new AceConfig();\n\t\tthis.windowConfig = new WindowConfig();\n\t\tthis.startupJS = new StartupJS();\n\n\t\tthis.el = this.createEl();\n\n\t\t$('.extension-data', this.el).append(this.extensionData.el);\n\t\t$('.ace-config', this.el).append(this.aceConfig.el);\n\t\t$('.window-config', this.el).append(this.windowConfig.el);\n\t\t$('.startup-js', this.el).append(this.startupJS.el);\n\n\t\tthis.addEvents();\n\n\t\tthis.editor = createEditor($('.editor-container', this.el));\n\n\t\tconst codePreview = $('.preview-inner', this.el);\n\t\tconst nameInput = $('input[name=\"name\"]', this.el);\n\t\tconst previewUserCode = () => {\n\t\t\tconst name = nameInput.value;\n\t\t\tconst userScript = `<span class=\"userscript\">${this.editor.getValue()}</span>`;\n\t\t\tconst script = generateScript(userScript).trim();\n\t\t\tcodePreview.innerHTML = script;\n\t\t};\n\t\tpreviewUserCode();\n\t\tthis.editor.on('change', previewUserCode);\n\t}\n\n\taddEvents() {\n\t\tstorage.loadOnce().then(() => storage.forEach('scripts', key => this.add(key)));\n\t\teventBus.on('storage-save', () => {\n\t\t\tthis.clear();\n\t\t\tstorage.forEach('scripts', key => this.add(key));\n\t\t});\n\n\t\t$('.scripts-list', this.el).addEventListener('click', this.onScriptClick);\n\n\t\t$('.script-item.create button', this.el).addEventListener('click', () => {\n\t\t\tthis.openEditing();\n\t\t});\n\t\t$('.cancel', this.el).addEventListener('click', () => {\n\t\t\tthis.closeEditing(boilerplate);\n\t\t});\n\n\t\t$('form', this.el).addEventListener('submit', e => this.onSubmit(e));\n\n\t\teventBus.on('scriptStatus', e => {\n\t\t\tconst { name, error } = e.detail;\n\t\t\tconst scriptItem = $(`.script-item[data-name=\"${name}\"]`, this.el);\n\t\t\tconst scriptInfo = $('.script-info', this.el);\n\n\t\t\tscriptItem.setAttribute('data-script-status', error ? 'error' : 'success');\n\n\t\t\tconst text = error ? this.formatErrorMessage(name, error) : 'No errors.';\n\t\t\tscriptInfo.innerHTML = text;\n\t\t\tscriptInfo.setAttribute('data-script-status', error ? 'error' : 'success');\n\t\t});\n\n\t\teventBus.on('resize', () => {\n\t\t\tthis.editor && this.el.classList.contains('editing') && this.editor.resize();\n\t\t});\n\t}\n\n\tcreateEl() {\n\t\tconst dummy = document.createElement('div');\n\t\tdummy.innerHTML = `\n\t\t\t<div class=\"scripts\">\n\t\t\t\t<div>\n\t\t\t\t\t<h2>Scripts</h2>\n\t\t\t\t\t<div class=\"tab-selection\"></div>\n\t\t\t\t\t<ul class=\"scripts-list\">\n\t\t\t\t\t\t<li class=\"script-item create\">\n\t\t\t\t\t\t\t<button class=\"script-button\" title=\"Create new script\">+</button>\n\t\t\t\t\t\t</li>\n\t\t\t\t\t</ul>\n\t\t\t\t\t<p><small>Meta+click to run a script and close this window.</small></p>\n\t\t\t\t\t<pre class=\"script-info\"> </pre>\n\t\t\t\t</div>\n\t\t\t\t<form>\n\t\t\t\t\t\t<h2>Script editor</h2>\n\t\t\t\t\t\t<p>\n\t\t\t\t\t\t\t<button type=\"button\" class=\"button cancel\" title=\"Cancel\">&#x00D7;</button>\n\t\t\t\t\t\t\t<button type=\"submit\" class=\"button\" title=\"Submit\">&check;</button>\n\t\t\t\t\t\t</p>\n\t\t\t\t\t\t<details>\n\t\t\t\t\t\t\t<summary>How it works</summary>\n\t\t\t\t\t\t\t<p>Write your code inside the function template. The function takes two arguments <strong>$</strong> and <strong>$$</strong>, which are similar to <strong>document.querySelector</strong> and <strong>document.querySelectorAll</strong>. These are locally defined functions and are not defined on <strong>window</strong>.</p>\n\t\t\t\t\t\t\t<p>Note: If \"run at\" is set to document start, end, or idle, the code will not have access to the <strong>window</strong> object.</p>\n\t\t\t\t\t\t</details>\n\t\t\t\t\t\t<details>\n\t\t\t\t\t\t\t<summary>Preview</summary>\n\t\t\t\t\t\t\t<pre class=\"preview\"><span class=\"preview-inner\"></span></pre>\n\t\t\t\t\t\t</details>\n\t\t\t\t\t\t<br/>\n\t\t\t\t\t\t<p>\n\t\t\t\t\t\t\t<label for=\"name\"><strong>Name: </strong></label>\n\t\t\t\t\t\t\t<input id=\"name\" name=\"name\" type=\"text\" autocomplete=\"off\" required/>\n\t\t\t\t\t\t</p>\n\t\t\t\t\t\t<div class=\"editor-container\"></div>\n\t\t\t\t\t\t<br/>\n\t\t\t\t\t\t<div>\n\t\t\t\t\t\t\t<div><span class=\"middle\"><strong>Run at: </strong></span></div>\n\t\t\t\t\t\t\t<div><input type=\"radio\" class=\"middle\" name=\"run-at\" value=\"click\" id=\"run-at-click\"><span class=\"middle\">button click</span></label></div>\n\t\t\t\t\t\t\t<div><input type=\"radio\" class=\"middle\" name=\"run-at\" value=\"document-start\" id=\"run-at-document-start\"><span class=\"middle\">document start</span></label></div>\n\t\t\t\t\t\t\t<div><input type=\"radio\" class=\"middle\" name=\"run-at\" value=\"document-end\" id=\"run-at-document-end\"><span class=\"middle\">document end</span></label></div>\n\t\t\t\t\t\t\t<div><input type=\"radio\" class=\"middle\" name=\"run-at\" value=\"document-idle\" id=\"run-at-document-idle\"><span class=\"middle\">document idle</span></label></div>\n\t\t\t\t\t\t\t<small>(<a href=\"https://developer.chrome.com/extensions/content_scripts#run_time\">https://developer.chrome.com/extensions/content_scripts#run_time</a>)</small>\n\t\t\t\t\t\t</div>\n\t\t\t\t</form>\n\t\t\t\t<div class=\"extension-data\"></div>\n\t\t\t</div>\n\t\t`;\n\t\treturn dummy.children[0];\n\t}\n\n\tcreateItem(name) {\n\t\tconst dummy = document.createElement('div');\n\t\tdummy.innerHTML = `\n\t\t\t<li class=\"script-item\" data-name=\"${name}\">\n\t\t\t\t<button class=\"script-button\" data-action=\"run\" title=\"Run script '${name}'\">${name}</button>\n\t\t\t\t<span class=\"actions\">\n\t\t\t\t\t<button data-action=\"delete\" title=\"Delete script\">&#x00D7;</button>\n\t\t\t\t\t<button data-action=\"edit\" title=\"Edit script\">&#x270E;</button>\n\t\t\t\t</span>\n\t\t\t</li>\n\t\t`;\n\t\treturn dummy.children[0];\n\t}\n\n\tclear() {\n\t\tArray.from($$('.script-item:not(.create)', this.el)).forEach(el => el.remove());\n\t}\n\n\tadd(name) {\n\t\tconst item = this.createItem(name);\n\t\t$('.scripts-list', this.el).append(item);\n\t}\n\n\topenEditing(text = boilerplate, name = '') {\n\t\tthis.el.classList.add('editing');\n\t\t$('form', this.el).setAttribute('data-edit-for', name);\n\n\t\t$('input[name=\"name\"]', this.el).value = name;\n\t\tconst runAt = (name && storage.get(`scripts.${name}`).runAt) || 'click';\n\t\t$(`input[id=\"run-at-${runAt}\"]`).checked = true;\n\n\t\tthis.editor.resize();\n\t\ttext && this.editor.setValue(text, 1);\n\t}\n\n\tcloseEditing(text) {\n\t\tthis.el.classList.remove('editing');\n\t\t$('form', this.el).removeAttribute('data-edit-for');\n\t\t$('input[name=\"name\"]', this.el).value = '';\n\t\tthis.editor.resize();\n\t\ttext && this.editor.setValue(text, 1);\n\t}\n\n\tonSubmit(e) {\n\t\te.preventDefault();\n\t\tconst data = new FormData(e.currentTarget);\n\t\tdata.set('script', this.editor.getValue());\n\n\t\tconst isValid = data.get('name') && data.get('script'); // TODO\n\n\t\tif (isValid) {\n\t\t\tconst editFor = $('form', this.el).getAttribute('data-edit-for');\n\t\t\tconst editedItem = $(`.script-item[data-name=\"${editFor}\"]`, this.el);\n\t\t\teditedItem && this.delete(editedItem);\n\n\t\t\tthis.add(name, data.get('script'));\n\t\t\teventBus.emit('scriptCreated', data);\n\t\t\tthis.closeEditing(boilerplate);\n\t\t}\n\t}\n\n\tonScriptClick(e) {\n\t\tif (e.target === e.currentTarget) {\n\t\t\treturn;\n\t\t}\n\n\t\tconst li = e.target.closest('li');\n\t\tconst action = e.target.getAttribute('data-action');\n\n\t\tif (action === 'delete') {\n\t\t\tif (e.metaKey) {\n\t\t\t\tthis.delete(li);\n\t\t\t} else {\n\t\t\t\tconfirm('Permanently delete script?') && this.delete(li);\n\t\t\t}\n\t\t} else if (action === 'edit') {\n\t\t\tthis.edit(li);\n\t\t} else if (action === 'run') {\n\t\t\teventBus.emit('scriptRun', li.getAttribute('data-name'));\n\t\t\te.metaKey && eventBus.emit('close');\n\t\t}\n\t}\n\n\tdelete(scriptItem) {\n\t\tscriptItem.remove();\n\t\teventBus.emit('scriptDeleted', scriptItem.getAttribute('data-name'));\n\t}\n\n\tedit(scriptItem) {\n\t\tconst name = scriptItem.getAttribute('data-name');\n\t\tconst { script } = storage.get(`scripts.${name}`);\n\t\tthis.openEditing(decodeURIComponent(script), name);\n\t}\n\n\tformatErrorMessage(name, error) {\n\t\tif (typeof error === 'string') {\n\t\t\treturn error;\n\t\t}\n\n\t\tconst lineNumber = this.getLineNumberFromStack(error.stack) - generateScript.codeBeginLine;\n\t\tconst code = decodeURIComponent(storage.get(`scripts.${name}`).script).split('\\n');\n\t\tcode[lineNumber - 1] = `<span class=\"error\">${code[lineNumber - 1]}</span>`;\n\t\treturn `Error found on line ${lineNumber}:\\n\\n<span class=\"userscript\">${code.join('\\n')}</span>\\n\\n${error.stack}`;\n\t}\n\n\tgetLineNumberFromStack(stack) {\n\t\tconst match = /at[^\\d]*:(\\d+):\\d+/.exec(stack);\n\t\treturn match && match[1];\n\t}\n};\n\n\n//# sourceURL=webpack:///./src/dom/Scripts.js?");

/***/ }),

/***/ "./src/dom/StartupJS.js":
/*!******************************!*\
  !*** ./src/dom/StartupJS.js ***!
  \******************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

eval("const { $, $$ } = __webpack_require__(/*! ../helpers/query-selector */ \"./src/helpers/query-selector.js\");\nconst storage = __webpack_require__(/*! ./storage */ \"./src/dom/storage.js\");\nconst eventBus = __webpack_require__(/*! ./event-bus */ \"./src/dom/event-bus.js\");\nconst formatCode = __webpack_require__(/*! ../helpers/format-code */ \"./src/helpers/format-code.js\");\nconst ConfigPanel = __webpack_require__(/*! ./ConfigPanel */ \"./src/dom/ConfigPanel.js\");\n\nmodule.exports = class StartupJS extends ConfigPanel {\n\tstatic get optionPath() {\n\t\treturn 'startupJSOptions';\n\t}\n\n\tstatic get editorCode() {\n\t\treturn formatCode.dedent(`\n\t\t\tfunction onStartup() {\n\t\t\t\tconst html = document.documentElement;\n\t\t\t\tif (html.classList.contains('popup')) {\n\t\t\t\t\thtml.style.minWidth = '540px';\n\t\t\t\t}\n\t\t\t}\n\t\t`).trim();\n\t}\n\n\tconstructor() {\n\t\tsuper(...arguments);\n\t\t$('.run', this.el).addEventListener('click', () => this.run());\n\t\teventBus.on('isPopup', () => this.run());\n\t}\n\n\tcreateEl() {\n\t\tconst dummy = document.createElement('div');\n\t\tdummy.innerHTML = `\n\t\t\t<details>\n\t\t\t\t<summary>Startup JS</summary>\n\t\t\t\t<p>Run this code when this extension window/popup is created.</p>\n\t\t\t\t<p>\n\t\t\t\t\t<button class=\"button restore-default\" title=\"Restore defaults\"><small>restore defaults</small></button>\n\t\t\t\t\t<button class=\"button run\" title=\"run\"><small>run</small></button>\n\t\t\t\t</p>\n\t\t\t\t<small class=\"save\" data-saved=\"Saved.\" data-saving=\"Saving...\">Saved.</small>\n\t\t\t\t<div class=\"editor-container\"></div>\n\t\t\t</details>\n\t\t`;\n\t\treturn dummy.children[0];\n\t}\n\n\trun() {\n\t\tconst fn = this.constructor.getOption();\n\t\tfn && eval(`(${fn})()`);\n\t}\n};\n\n\n//# sourceURL=webpack:///./src/dom/StartupJS.js?");

/***/ }),

/***/ "./src/dom/TabSelection.js":
/*!*********************************!*\
  !*** ./src/dom/TabSelection.js ***!
  \*********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

eval("const { $, $$ } = __webpack_require__(/*! ../helpers/query-selector */ \"./src/helpers/query-selector.js\");\n\nmodule.exports = class TabSelection {\n\tconstructor() {\n\t\tthis.el = this.createEl();\n\t\tthis.populateTabs();\n\t\tthis.addEvents();\n\t}\n\n\tcreateEl() {\n\t\tconst dummy = document.createElement('div');\n\t\tdummy.innerHTML = `\n\t\t\t<div>\n\t\t\t\t<select class=\"tab-hrefs\"></select>\n\t\t\t\t<button class=\"button last-active\" title=\"Get last active tab\">last active</button>\n\t\t\t\t<button class=\"button refresh\" title=\"refresh\">&orarr;</button>\n\t\t\t</div>\n\t\t`;\n\t\treturn dummy.children[0];\n\t}\n\n\tpopulateTabs() {\n\t\tconst select = $('.tab-hrefs', this.el);\n\t\tArray.from(select.children).forEach(el => el.remove());\n\n\t\tchrome.tabs.query({ currentWindow: false }, tabs => {\n\t\t\ttabs.forEach(tab => {\n\t\t\t\tconst option = document.createElement('option');\n\t\t\t\toption.setAttribute('data-url', tab.url);\n\t\t\t\toption.setAttribute('data-index', tab.index);\n\t\t\t\toption.textContent = tab.url;\n\t\t\t\toption.selected = tab.selected;\n\t\t\t\tselect.append(option);\n\t\t\t});\n\t\t});\n\t}\n\n\taddEvents() {\n\t\t$('.last-active', this.el).addEventListener('click', () => {\n\t\t\tchrome.tabs.query({ currentWindow: false, active: true }, tabs => {\n\t\t\t\tconst option = $(`option[data-url=\"${tabs[0].url}\"]`, this.el);\n\t\t\t\toption.selected = true;\n\t\t\t});\n\t\t});\n\n\t\t$('.refresh', this.el).addEventListener('click', () => this.populateTabs());\n\t}\n\n\tgetSelectedTab() {\n\t\tconst select = $('select', this.el);\n\t\tconst option = select.children[select.selectedIndex];\n\t\treturn {\n\t\t\turl: option.getAttribute('data-url'),\n\t\t\tindex: parseInt(option.getAttribute('data-index'))\n\t\t};\n\t}\n};\n\n\n//# sourceURL=webpack:///./src/dom/TabSelection.js?");

/***/ }),

/***/ "./src/dom/WindowConfig.js":
/*!*********************************!*\
  !*** ./src/dom/WindowConfig.js ***!
  \*********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

eval("const { $, $$ } = __webpack_require__(/*! ../helpers/query-selector */ \"./src/helpers/query-selector.js\");\nconst formatCode = __webpack_require__(/*! ../helpers/format-code */ \"./src/helpers/format-code.js\");\nconst ConfigPanel = __webpack_require__(/*! ./ConfigPanel */ \"./src/dom/ConfigPanel.js\");\n\nmodule.exports = class WindowConfig extends ConfigPanel {\n\tstatic get optionPath() {\n\t\treturn 'windowOptions';\n\t}\n\n\tstatic get editorCode() {\n\t\treturn formatCode.dedent(`\n\t\t\tfunction configureWindow() {\n\t\t\t\treturn {\n\t\t\t\t\ttype: 'popup',\n\t\t\t\t\ttop: 40,\n\t\t\t\t\tleft: 20,\n\t\t\t\t\twidth: 730,\n\t\t\t\t\theight: 540\n\t\t\t\t};\n\t\t\t}\n\t\t`).trim();\n\t}\n\n\tcreateEl() {\n\t\tconst dummy = document.createElement('div');\n\t\tdummy.innerHTML = `\n\t\t\t<details>\n\t\t\t\t<summary>Configure extension window</summary>\n\t\t\t\t<p>This options object will be used when opening this extension in a separate window (see <a href=\"https://developer.chrome.com/extensions/windows#method-create\">docs</a> for details).</p>\n\t\t\t\t<p><button class=\"button restore-default\" title=\"Restore defaults\"><small>restore defaults</small></button></p>\n\t\t\t\t<small class=\"save\" data-saved=\"Saved.\" data-saving=\"Saving...\">Saved.</small>\n\t\t\t\t<div class=\"editor-container\"></div>\n\t\t\t</details>\n\t\t`;\n\t\treturn dummy.children[0];\n\t}\n};\n\n\n//# sourceURL=webpack:///./src/dom/WindowConfig.js?");

/***/ }),

/***/ "./src/dom/add-resize-event.js":
/*!*************************************!*\
  !*** ./src/dom/add-resize-event.js ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("// expects el to have CSS `resize`\nmodule.exports = (el, debounce = 100) => {\n\tconst { style } = el;\n\tlet id;\n\n\tconst debouncer = (...args) => {\n\t\tclearTimeout(id);\n\t\tid = setTimeout(() => cb(...args), debounce);\n\t};\n\n\tconst cb = (mutationsList) => {\n\t\tlet resized = false;\n\n\t\tfor (const mutation of mutationsList) {\n\t\t\tif (mutation.attributeName === 'style') {\n\t\t\t\t['width', 'height'].forEach(prop => {\n\t\t\t\t\tif (el.getAttribute(`data-prev-${prop}`) !== style[prop]) {\n\t\t\t\t\t\tresized = true;\n\t\t\t\t\t}\n\n\t\t\t\t\tel.setAttribute(`data-prev-${prop}`, style[prop])\n\t\t\t\t});\n\t\t\t}\n\t\t}\n\n\t\tif (resized) {\n\t\t\tel.dispatchEvent(new CustomEvent('resize'));\n\t\t}\n\t};\n\n\tconst observer = new MutationObserver(debouncer);\n\tobserver.observe(el, { attributes: true });\n};\n\n\n//# sourceURL=webpack:///./src/dom/add-resize-event.js?");

/***/ }),

/***/ "./src/dom/configure-editor.js":
/*!*************************************!*\
  !*** ./src/dom/configure-editor.js ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

eval("const { $, $$ } = __webpack_require__(/*! ../helpers/query-selector */ \"./src/helpers/query-selector.js\");\nconst storage = __webpack_require__(/*! ./storage */ \"./src/dom/storage.js\");\n\nmodule.exports = async () => {\n\tawait storage.loadOnce();\n\n\t$$('.editor-container').forEach(el => {\n\t\tconst fn = decodeURIComponent(storage.get('aceOptions'));\n\t\tfn && eval(`(${fn})(el.editor)`);\n\t});\n};\n\n\n//# sourceURL=webpack:///./src/dom/configure-editor.js?");

/***/ }),

/***/ "./src/dom/create-editor.js":
/*!**********************************!*\
  !*** ./src/dom/create-editor.js ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

eval("const addResizeEvent = __webpack_require__(/*! ./add-resize-event */ \"./src/dom/add-resize-event.js\");\n\nmodule.exports = (el) => {\n\tconst editor = window.ace.edit(el);\n\taddResizeEvent(el);\n\tel.addEventListener('resize', () => editor.resize());\n\tel.editor = editor;\n\treturn editor;\n};\n\n\n//# sourceURL=webpack:///./src/dom/create-editor.js?");

/***/ }),

/***/ "./src/dom/css.js":
/*!************************!*\
  !*** ./src/dom/css.js ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("module.exports = `\nbody {\n\tmargin: 0;\n}\n\n#gorilla {\n\tfont-family: monospace;\n\tfont-size: 12px;\n\tpadding: 20px;\n\t--cyan: #00caa2;\n\t--purple: #ff00d3;\n}\n\n* {\n\tfont-family: inherit;\n}\n\nbutton {\n\tbackground: white;\n}\nbutton.button {\n\t--hover-border: var(--cyan);\n\t--active-border: var(--purple);\n\t--hover-shadow: 0px 0px 6px 0px var(--hover-border);\n}\nbutton:not([disabled]) {\n\tcursor: pointer;\n}\n.button:active {\n\t--hover-border: var(--active-border);\n}\n.button:hover {\n\tbox-shadow: var(--hover-shadow);\n\tborder-color: var(--hover-border)\n}\n\n.middle {\n\tvertical-align: middle;\n}\n\ndetails {\n\tpadding: 4px;\n\tmargin: 0.5em 0;\n}\ndetails[open] {\n\tborder: 1px solid gray;\n\tbackground: white;\n}\ndetails summary {\n\twidth: min-content;\n\twhite-space: nowrap;\n\tcursor: pointer;\n\tfont-size: 1.2em;\n}\n\n.editor-container {\n\tresize: vertical;\n\tmin-width: 400px;\n\tmin-height: 200px;\n\twidth: 100%;\n}\n\n.tab-hrefs {\n\tmax-width: 300px;\n}\n\n.storage-container {\n\tposition: relative;\n}\n.storage-container textarea {\n\tz-index: -1;\n\tposition: absolute;\n\ttop: 0;\n\tleft: 0;\n\tright: 0;\n\tbottom: 0;\n}\n\nbutton {\n\tborder: 1px solid #8e8e8e;\n\tborder-radius: 4px;\n}\n\n.scripts pre {\n\tpadding: 8px;\n\tbackground: black;\n\tcolor: white;\n\twhite-space: pre-wrap;\n}\n.scripts .preview {\n\twhite-space: pre;\n\toverflow: scroll;\n}\npre .userscript {\n\tcolor: yellow;\n}\npre .error {\n\tbackground: red;\n}\n\n.scripts:not(.editing) form {\n\tdisplay: none;\n}\n.scripts.editing > *:not(form) {\n\tdisplay: none;\n}\n\n.scripts-list, .item {\n\tlist-style: none;\n}\n\n.scripts-list {\n\tdisplay: grid;\n\tgrid-template-columns: repeat(auto-fit, 150px);\n\tgrid-auto-rows: 1fr;\n\tgrid-gap: 16px;\n\tmargin: 10px 0 0 0;\n\tpadding: 0;\n}\n\n.scripts .script-item {\n\tposition: relative;\n}\n\n.scripts .script-item .actions {\n\ttransform: scale(0.8);\n\topacity: 0;\n\ttransition: transform 0.13s, opacity 0.1s;\n\tposition: absolute;\n\ttop: 4px;\n\tleft: 4px;\n\tdisplay: flex;\n\tflex-direction: column;\n}\n\n.scripts .script-item .actions button {\n\ttransform: scale(1);\n\ttransition: transform 0.1s;\n\tpadding: 0 4px;\n}\n\n.scripts .script-item .actions button:hover {\n\ttransform: scale(1.2);\n}\n\n.scripts .script-item .actions button:not(:first-child) {\n\tmargin-top: 2px;\n}\n\n.scripts .script-item:hover .actions {\n\ttransform: scale(1);\n\topacity: 1;\n}\n\n.scripts .script-item .script-button {\n\tposition: relative;\n\toverflow: hidden;\n\twidth: 100%;\n\theight: 100%;\n\tborder: 2px solid transparent;\n\tborder-radius: 8px;\n\tbackground: gray;\n\tcolor: white;\n\tpadding: 8px 22px;\n\tbox-sizing: border-box;\n\toutline: none;\n}\n\n.scripts .script-item .script-button::after {\n\topacity: 0;\n\ttransition: opacity 0.2s;\n\tpointer-events: none;\n\tdisplay: block;\n\tcontent: '';\n\tposition: absolute;\n\ttop: 0;\n\tleft: 0;\n\tright: 0;\n\tbottom: 0;\n\tbackground: radial-gradient(transparent, rgba(0, 0, 0, 0.2));\n}\n\n.scripts .script-item:hover button::after {\n\topacity: 1;\n}\n\n.scripts .script-item[data-script-status=\"success\"] .script-button { border: 2px solid #00ca00; }\n.scripts .script-item[data-script-status=\"error\"] .script-button { border: 2px dashed red; }\n\n.script-item.create {\n\torder: 1;\n}\n.script-item.create .script-button {\n\tbackground: #00a200;\n}\n\n.scripts form {\n\tbackdrop-filter: blur(10px);\n\tbox-sizing: border-box;\n\tbackground: rgba(255, 255, 255, 0.75);\n}\n.scripts form .scrollable {\n\toverflow: scroll;\n\tdisplay: flex;\n\tflex-direction: column;\n}\n\n.scripts form button {\n\tpadding: 5px 10px;\n}\n\n.script-info:not([data-script-status]) {\n\tdisplay: none;\n}\n\ninput {\n\tbox-sizing: border-box;\n\tborder-radius: 5px;\n\tborder: 1px solid #333;\n\tpadding: 5px 10px;\n}\ninput[type=\"radio\"] {\n\tmargin-top: 0;\n}\n`;\n\n\n//# sourceURL=webpack:///./src/dom/css.js?");

/***/ }),

/***/ "./src/dom/event-bus.js":
/*!******************************!*\
  !*** ./src/dom/event-bus.js ***!
  \******************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("class EventBus {\n\tconstructor(el = document.documentElement) {\n\t\tthis.el = el;\n\t}\n\n\ton() {\n\t\tthis.el.addEventListener(...arguments);\n\t}\n\n\tonce(name, listener) {\n\t\tconst fn = (...args) => {\n\t\t\tthis.off(name, fn);\n\t\t\tlistener(...args);\n\t\t};\n\t\tthis.on(name, fn);\n\t}\n\n\toff() {\n\t\tthis.el.removeEventListener(...arguments);\n\t}\n\n\temit(eventName, data) {\n\t\tthis.el.dispatchEvent(new CustomEvent(eventName, { detail: data }));\n\t}\n}\n\nmodule.exports = new EventBus();\n\n\n//# sourceURL=webpack:///./src/dom/event-bus.js?");

/***/ }),

/***/ "./src/dom/index.js":
/*!**************************!*\
  !*** ./src/dom/index.js ***!
  \**************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

eval("const Gorilla = __webpack_require__(/*! ./Gorilla */ \"./src/dom/Gorilla.js\");\nnew Gorilla();\n\n\n//# sourceURL=webpack:///./src/dom/index.js?");

/***/ }),

/***/ "./src/dom/storage.js":
/*!****************************!*\
  !*** ./src/dom/storage.js ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

eval("const DelimitedMap = __webpack_require__(/*! ./DelimitedMap */ \"./src/dom/DelimitedMap.js\");\nconst eventBus = __webpack_require__(/*! ./event-bus */ \"./src/dom/event-bus.js\");\n\nclass Storage extends DelimitedMap {\n\tconstructor() {\n\t\tsuper(...arguments);\n\t\tthis._loadOnce = null;\n\t\tthis.loadOnce();\n\t}\n\n\tloadOnce() {\n\t\tif (!this._loadOnce) {\n\t\t\tthis._loadOnce = this.load();\n\t\t}\n\t\treturn this._loadOnce;\n\t}\n\n\tload() {\n\t\treturn new Promise(resolve => {\n\t\t\tchrome.storage.local.get(data => {\n\t\t\t\tthis.json = data.gorilla || {};\n\t\t\t\tresolve();\n\t\t\t});\n\t\t});\n\t}\n\n\tsave() {\n\t\treturn new Promise(resolve => {\n\t\t\tchrome.storage.local.set({ gorilla: this.json }, () => {\n\t\t\t\teventBus.emit('storage-save');\n\t\t\t\tresolve();\n\t\t\t});\n\t\t});\n\t}\n};\n\nmodule.exports = new Storage();\n\n\n//# sourceURL=webpack:///./src/dom/storage.js?");

/***/ }),

/***/ "./src/helpers/format-code.js":
/*!************************************!*\
  !*** ./src/helpers/format-code.js ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("/**\n * Removes annoying extra indents when using template literals. Assumes the\n * given string is correctly formatted. Expects something like this (important\n * to begin with newline):\n *\n * const code = `\n *\tfunction () {\n *\t\tconsole.log(10 * 10);\n *\t}\n * `;\n * dedent(code);\n */\nmodule.exports = {\n\tdedent(code) {\n\t\tconst numIndents = this.getNumIndentsAtLine(code, 1);\n\t\treturn code.split('\\n').map(line => line.slice(numIndents)).join('\\n');\n\t},\n\n\t/**\n\t * Code must begin with newline. First \"line\" of code is at lineNum 1.\n\t */\n\tgetNumIndentsAtLine(code, lineNum) {\n\t\tconst line = code.split('\\n')[lineNum];\n\t\treturn /^(\\s*)/.exec(line)[1].split(/\\s/).length - 1;\n\t},\n\n\tindent(code, num = 0, char = '\\t') {\n\t\tconst indentString = new Array(num).fill(char).join('');\n\t\treturn code.split('\\n').map(line => `${indentString}${line}`).join('\\n');\n\t},\n\n\treplaceLine(code, lineNum, string) {\n\t\tconst lines = code.split('\\n');\n\t\tlines[lineNum] = string;\n\t\treturn lines.join('\\n');\n\t}\n};\n\n\n//# sourceURL=webpack:///./src/helpers/format-code.js?");

/***/ }),

/***/ "./src/helpers/generate-script.js":
/*!****************************************!*\
  !*** ./src/helpers/generate-script.js ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

eval("const { $, $$ } = __webpack_require__(/*! ./query-selector */ \"./src/helpers/query-selector.js\");\nconst formatCode = __webpack_require__(/*! ./format-code */ \"./src/helpers/format-code.js\");\n\nconst DEFAULTS = { indentLevel: 0 };\n\nconst LINE = 5;\n\nmodule.exports = (userScript, options) => {\n\toptions = { ...DEFAULTS, ...options };\n\n\tlet code = formatCode.dedent(`\n\t\t(function() {\n\t\t\tconst $ = ${$.toString()};\n\t\t\tconst $$ = ${$$.toString()};\n\n\t\t\t// line 5\n\n\t\t\t// boilerplate error handling\n\t\t\ttry {\n\t\t\t\tconst ret = (gorillaScript)($, $$);\n\t\t\t\tret instanceof Promise ? ret.then(finish).catch(finish) : finish();\n\t\t\t} catch(e) {\n\t\t\t\tfinish(e);\n\t\t\t}\n\n\t\t\tfunction finish(error) {\n\t\t\t\terror instanceof Error && console.error(error);\n\t\t\t\tconst data = { detail: error };\n\t\t\t\tconst event = new CustomEvent('gorilla-script-status', data);\n\t\t\t\tdocument.documentElement.dispatchEvent(event);\n\t\t\t}\n\t\t})();\n\t`);\n\n\tif (options.indentLevel) {\n\t\tcode = formatCode.indent(code, options.indentLevel);\n\t}\n\n\tconst numIndents = formatCode.getNumIndentsAtLine(code, LINE);\n\tuserScript = formatCode.indent(`const gorillaScript = ${userScript};`, numIndents, '\\t');\n\n\treturn formatCode.replaceLine(code, LINE, userScript).replace(/\\s*$/, '\\n');\n};\n\nmodule.exports.codeBeginLine = LINE;\n\n\n//# sourceURL=webpack:///./src/helpers/generate-script.js?");

/***/ }),

/***/ "./src/helpers/query-selector.js":
/*!***************************************!*\
  !*** ./src/helpers/query-selector.js ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("module.exports = {\n\t$: (sel, node = document) => { return node.querySelector(sel); },\n\t$$: (sel, node = document) => { return node.querySelectorAll(sel); }\n};\n\n\n//# sourceURL=webpack:///./src/helpers/query-selector.js?");

/***/ })

/******/ });