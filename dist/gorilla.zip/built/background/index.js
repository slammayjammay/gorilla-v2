/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/background/index.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/background/index.js":
/*!*********************************!*\
  !*** ./src/background/index.js ***!
  \*********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

eval("const generateScript = __webpack_require__(/*! ../helpers/generate-script */ \"./src/helpers/generate-script.js\");\n\nchrome.runtime.onMessage.addListener((request, sender, respond) => {\n\tif (request.name === 'open-popup') {\n\t\tcreateWindow();\n\t} else if (request.name === 'run-script') {\n\t\tgetScript(request.scriptName).then(code => {\n\t\t\tlet tabQuery;\n\n\t\t\tif (!request.tabQuery && !sender.tab) {\n\t\t\t\ttabQuery = { active: true, currentWindow: true };\n\t\t\t} else if (request.tabQuery) {\n\t\t\t\ttabQuery = request.tabQuery;\n\t\t\t} else if (sender.tab) {\n\t\t\t\ttabQuery = { id: sender.tab.id };\n\t\t\t}\n\n\t\t\trunScript(code, tabQuery).then(respond);\n\t\t});\n\t\treturn true;\n\t}\n});\n\nasync function createWindow(tab) {\n\tconst data = await new Promise(r => chrome.storage.local.get(r));\n\n\tlet options = {\n\t\ttype: 'popup',\n\t\ttop: 40,\n\t\tleft: 20,\n\t\twidth: 730,\n\t\theight: 540\n\t};\n\n\tif (data.gorilla && data.gorilla.windowOptions) {\n\t\toptions = eval(`(${decodeURIComponent(data.gorilla.windowOptions)})()`);\n\t}\n\n\tchrome.windows.create({ ...options, url: 'popup.html' });\n}\n\nasync function getScript(name) {\n\tconst data = await new Promise(r => chrome.storage.local.get(r));\n\treturn decodeURIComponent(data.gorilla.scripts[name].script);\n}\n\nfunction runScript(code, tabQuery = { active: true, currentWindow: true }) {\n\treturn new Promise(async resolve => {\n\t\tcode = generateScript(code);\n\n\t\tchrome.runtime.onMessage.addListener(function once(request) {\n\t\t\tif (request.name === 'script-status') {\n\t\t\t\tchrome.runtime.onMessage.removeListener(once);\n\t\t\t\tresolve(request);\n\t\t\t}\n\t\t});\n\n\t\tif (tabQuery.id) {\n\t\t\treturn chrome.tabs.executeScript(tabQuery.id, { code });\n\t\t}\n\n\t\tchrome.tabs.query(tabQuery || { active: true, currentWindow: true }, tabs => {\n\t\t\tchrome.tabs.executeScript(tabs[0].id, { code });\n\t\t});\n\t});\n}\n\n\n//# sourceURL=webpack:///./src/background/index.js?");

/***/ }),

/***/ "./src/helpers/format-code.js":
/*!************************************!*\
  !*** ./src/helpers/format-code.js ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("/**\n * Removes annoying extra indents when using template literals. Assumes the\n * given string is correctly formatted. Expects something like this (important\n * to begin with newline):\n *\n * const code = `\n *\tfunction () {\n *\t\tconsole.log(10 * 10);\n *\t}\n * `;\n * dedent(code);\n */\nmodule.exports = {\n\tdedent(code) {\n\t\tconst numIndents = this.getNumIndentsAtLine(code, 1);\n\t\treturn code.split('\\n').map(line => line.slice(numIndents)).join('\\n');\n\t},\n\n\t/**\n\t * Code must begin with newline. First \"line\" of code is at lineNum 1.\n\t */\n\tgetNumIndentsAtLine(code, lineNum) {\n\t\tconst line = code.split('\\n')[lineNum];\n\t\treturn /^(\\s*)/.exec(line)[1].split(/\\s/).length - 1;\n\t},\n\n\tindent(code, num = 0, char = '\\t') {\n\t\tconst indentString = new Array(num).fill(char).join('');\n\t\treturn code.split('\\n').map(line => `${indentString}${line}`).join('\\n');\n\t},\n\n\treplaceLine(code, lineNum, string) {\n\t\tconst lines = code.split('\\n');\n\t\tlines[lineNum] = string;\n\t\treturn lines.join('\\n');\n\t}\n};\n\n\n//# sourceURL=webpack:///./src/helpers/format-code.js?");

/***/ }),

/***/ "./src/helpers/generate-script.js":
/*!****************************************!*\
  !*** ./src/helpers/generate-script.js ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

eval("const { $, $$ } = __webpack_require__(/*! ./query-selector */ \"./src/helpers/query-selector.js\");\nconst formatCode = __webpack_require__(/*! ./format-code */ \"./src/helpers/format-code.js\");\n\nconst DEFAULTS = { indentLevel: 0 };\n\nconst LINE = 5;\n\nmodule.exports = (userScript, options) => {\n\toptions = { ...DEFAULTS, ...options };\n\n\tlet code = formatCode.dedent(`\n\t\t(function() {\n\t\t\tconst $ = ${$.toString()};\n\t\t\tconst $$ = ${$$.toString()};\n\n\t\t\t// line 5\n\n\t\t\t// boilerplate error handling\n\t\t\ttry {\n\t\t\t\tconst ret = (gorillaScript)($, $$);\n\t\t\t\tret instanceof Promise ? ret.then(finish).catch(finish) : finish();\n\t\t\t} catch(e) {\n\t\t\t\tfinish(e);\n\t\t\t}\n\n\t\t\tfunction finish(error) {\n\t\t\t\terror instanceof Error && console.error(error);\n\t\t\t\tconst data = { detail: error };\n\t\t\t\tconst event = new CustomEvent('gorilla-script-status', data);\n\t\t\t\tdocument.documentElement.dispatchEvent(event);\n\t\t\t}\n\t\t})();\n\t`);\n\n\tif (options.indentLevel) {\n\t\tcode = formatCode.indent(code, options.indentLevel);\n\t}\n\n\tconst numIndents = formatCode.getNumIndentsAtLine(code, LINE);\n\tuserScript = formatCode.indent(`const gorillaScript = ${userScript};`, numIndents, '\\t');\n\n\treturn formatCode.replaceLine(code, LINE, userScript).replace(/\\s*$/, '\\n');\n};\n\nmodule.exports.codeBeginLine = LINE;\n\n\n//# sourceURL=webpack:///./src/helpers/generate-script.js?");

/***/ }),

/***/ "./src/helpers/query-selector.js":
/*!***************************************!*\
  !*** ./src/helpers/query-selector.js ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("module.exports = {\n\t$: (sel, node = document) => { return node.querySelector(sel); },\n\t$$: (sel, node = document) => { return node.querySelectorAll(sel); }\n};\n\n\n//# sourceURL=webpack:///./src/helpers/query-selector.js?");

/***/ })

/******/ });